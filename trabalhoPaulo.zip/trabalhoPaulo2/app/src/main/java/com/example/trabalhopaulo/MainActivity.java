package com.example.trabalhopaulo;

import android.os.Bundle;
import android.view.View;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {



            private EditText editNome, editEmail, editIdade, editDisciplina, editNota1, editNota2;
            private TextView textResultado, textErro;
            private List<String> respostas = new ArrayList<>();

            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);

                editNome = findViewById(R.id.editNome);
                editEmail = findViewById(R.id.editEmail);
                editIdade = findViewById(R.id.editIdade);
                editDisciplina = findViewById(R.id.editDisciplina);
                editNota1 = findViewById(R.id.editNota1);
                editNota2 = findViewById(R.id.editNota2);
                Button buttonEnviar = findViewById(R.id.buttonEnviar);
                Button buttonLimpard = findViewById(R.id.buttonLimpard);
                textResultado = findViewById(R.id.textResultado);
                textErro = findViewById(R.id.textErro);

                buttonEnviar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        validarDados();
                    }
                });

                buttonLimpard.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        resetarCampos();
                    }
                });
            }

            private void validarDados() {
                String nome = editNome.getText().toString();
                String email = editEmail.getText().toString();
                String idadeStr = editIdade.getText().toString();
                String disciplina = editDisciplina.getText().toString();
                String nota1Str = editNota1.getText().toString();
                String nota2Str = editNota2.getText().toString();
                StringBuilder erros = new StringBuilder();

                int idade = 0;
                float nota1 = -1; // -1 para indicar nota inválida
                float nota2 = -1; // -1 para indicar nota inválida


                if (nome.isEmpty()) {
                    erros.append("O campo de nome está vazio.\n");
                }
                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    erros.append("O email é inválido.\n");
                }
                if (disciplina.isEmpty()) {
                    erros.append("O campo de disciplina está vazio.\n");
                }
                try {
                    idade = Integer.parseInt(idadeStr);
                    if (idade <= 0) {
                        erros.append("A idade deve ser um número positivo.\n");
                    }
                } catch (NumberFormatException e) {
                    erros.append("A idade deve ser um número válido.\n");
                }

                try {
                    nota1 = Float.parseFloat(nota1Str);
                    if (nota1 < 0 || nota1 > 10) {
                        erros.append("A Nota 1º Bimestre deve estar entre 0 e 10.\n");
                    }
                } catch (NumberFormatException e) {
                    erros.append("A Nota 1º Bimestre deve ser um número válido.\n");
                }

                try {
                    nota2 = Float.parseFloat(nota2Str);
                    if (nota2 < 0 || nota2 > 10) {
                        erros.append("A Nota 2º Bimestre deve estar entre 0 e 10.\n");
                    }
                } catch (NumberFormatException e) {
                    erros.append("A Nota 2º Bimestre deve ser um número válido.\n");
                }

                if (erros.length() > 0) {
                    textErro.setText(erros.toString());
                    textResultado.setText("");
                } else {
                    textErro.setText("");
                    exibirDados(nome, email, idade, disciplina, nota1, nota2);
                }
            }

            private void exibirDados(String nome, String email, int idade, String disciplina, float nota1, float nota2) {
                float media = (nota1 + nota2) / 2;
                String status = media >= 6 ? "Aprovado" : "Reprovado";

                String novaResposta = "Nome: " + nome + "\n" +
                        "Email: " + email + "\n" +
                        "Idade: " + idade + "\n" +
                        "Disciplina: " + disciplina + "\n" +
                        "Nota 1º Bimestre: " + nota1 + "\n" +
                        "Nota 2º Bimestre: "  + nota2 + "\n" +
                        "Média: " + media + "\n" +
                        "Status: " + status + "\n\n";

                respostas.add(0, novaResposta);
                textResultado.setText(TextUtils.join("", respostas));
        }


   /* private void exibirDados(String nome, String email, int idade, String disciplina, float nota1, float nota2) {
                float media = (nota1 + nota2) / 2;
                String resultado = "Nome: " + nome + "\n" +
                        "Email: " + email + "\n" +
                        "Idade: " + idade + "\n" +
                        "Disciplina: " + disciplina + "\n" +
                        "Nota 1º Bimestre: " + nota1 + "\n" +
                        "Nota 2º Bimestre: " + nota2 + "\n" +
                        "Média: " + media + "\n" +
                        (media >= 6 ? "Aprovado" : "Reprovado");
                textResultado.setText(resultado);
            }


    */
            private void resetarCampos() {
                editNome.setText("");
                editEmail.setText("");
                editIdade.setText("");
                editDisciplina.setText("");
                editNota1.setText("");
                editNota2.setText("");
                textResultado.setText("");
                textErro.setText("");
            }
        }






